
# SauceDemo Cypress Tests

This project contains Cypress end-to-end tests for https://www.saucedemo.com/

## 🚀 Setup Instructions

1. Clone this repo:
   ```bash
   git clone https://github.com/your-username/saucedemo-cypress.git
   cd saucedemo-cypress
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Run Cypress:
   ```bash
   npx cypress open
   ```

4. Run tests in headless mode:
   ```bash
   npm test
   ```

## ✅ Test Coverage

- Login (valid, invalid, empty, locked-out)
- Cart (add, remove, view)
- Checkout (enter info, confirm order)
